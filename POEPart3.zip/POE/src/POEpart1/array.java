/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package POEpart1;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Asus
 */
//Code attribution:
//This code was adapted from https://www.youtube.com/watch?v=VAGpbAbSRTA&t=560s
//Code attribution:
//This code was adapted from https://www.youtube.com/watch?v=yHvQVc0WUF4&t=279s

public class array {
 public static ArrayList<String>DevNames=new ArrayList<>(); 
public static ArrayList<String>TSKNames=new ArrayList<>(); 
public static ArrayList<String>TSKIDs=new ArrayList<>(); 
public static ArrayList<Double>TSKDuration=new ArrayList<>(); 
public static ArrayList<String>TSKStatus=new ArrayList<>(); 
public static void addDevNames(String developerDetails){
   DevNames.add(Application.developerDetails);
}
public static void addTSKNames(String taskName){
   TSKNames.add(Application.taskName);
}
public static void addTSKID(String taskID){
   TSKIDs.add(Application.taskID);
}
public static void addTSKDuration(double taskDurations){
   TSKDuration.add(taskDurations);
}
public static void addTSKStatus(String taskStatus){
   TSKStatus.add(Application.taskStatus);
}
public static String[]FindDeveloperNames(){
    return DevNames.toArray(new String[0]);
}
public static String[]FindTaskNames(){
    return TSKNames.toArray(new String[0]);
}
public static String[]FindTSKIDs(){
    return TSKIDs.toArray(new String[0]);
}
public static Double[]FindTaskDurations(){
    return TSKDuration.toArray(new Double[0]);
}
public static String[]FindTaskStatus(){
    return TSKStatus.toArray(new String[0]);
}
public static String showFinishedTasks(){
    String TasksDone="";
    boolean found=false;
    for(int i=0;i<TSKStatus.size();i++){
        if(TSKStatus.get(i).equalsIgnoreCase("Done")){
            TasksDone+="Developer:"+DevNames.get(i)+"\n"
                    +"Task Name:"+TSKNames.get(i)+"\n"
                    +"Task Duration:"+TSKDuration.get(i)+"\n\n";
            found=true;
        }
    }
    if(!found){
        return"There are no task that meet these requirements";
    }
    return TasksDone;
}
public static String FindLongestDuration(){
    if(TSKDuration.isEmpty()){
        return "There are no tasks that meet these requirements";
        }
    int LongIndex=0;
    double LongDuration=TSKDuration.get(LongIndex);
    for (int i=1;i<TSKDuration.size();i++){
        if(TSKDuration.get(i)>LongDuration){
            LongDuration=TSKDuration.get(i);
            LongIndex=i;
        }
    }
    return "Developer:"+DevNames.get(LongIndex)+"\n"
            +"Task Name:"+TSKNames.get(LongIndex)+"\n"
            +"Duration:"+LongDuration;
}
public static String TaskNameSearch(){
    String NameTSK=JOptionPane.showInputDialog("Enter the name of desired task:");
    String TSKDetails="";
    boolean found=false;
    for(int i=0;i<TSKNames.size();i++){
        if(TSKNames.get(i).equalsIgnoreCase(NameTSK)){
            TSKDetails+="Task Name:"+TSKNames.get(i)+"\n"
                    +"Developer:"+DevNames.get(i)+"\n"
                    +"TaskStatus"+TSKStatus.get(i)+"\n\n";
            found =true;
        }
    }
    if(!found){
        return "Task name not found";
    }
    return TSKDetails;
            }
public static String DeveloperNameSearch(){
    String DevelopName=JOptionPane.showInputDialog("Enter the developer to search for:");
    String TSKDetails="";
    boolean found=false;
    for(int i=0;i<DevNames.size();i++){
        if(DevNames.get(i).equalsIgnoreCase(DevelopName)){
            TSKDetails+="Task Name:"+TSKNames.get(i)+"\n"
                    +"Task Status:"+TSKStatus.get(i)+"\n\n";
            found=true;
        }
    }
    if(!found){
        return "Developer name not found";
    }
    return TSKDetails;
}
public static String NameDelete(){
    String TSKNM=JOptionPane.showInputDialog("Enter the name of the task you want to delete");
    boolean found=false;
    for (int i=0;i<TSKNames.size();i++){
        if(TSKNames.get(i).equalsIgnoreCase(TSKNM)){
            DevNames.remove(i);
            TSKNames.remove(i);
            TSKIDs.remove(i);
            TSKDuration.remove(i);
            TSKStatus.remove(i);
            found=true;
            break;
        }
    }
    if(!found){
        return "task not found";
    }
    return "task deleted";
}
public static String FindAllTaskDetails(){
    if(TSKNames.isEmpty()){
        return "No tasks available";
    }
    String allTaskDetails="";
    for (int i=0;i<TSKNames.size();i++){
     allTaskDetails+="Task Names:"+TSKNames.get(i)+"\n"
             +"Developer:"+DevNames.get(i)+"\n"
             +"Task Duration:"+TSKDuration.get(i)+"\n"
             +"Status"+TSKStatus.get(i)+"\n\n";
    }
    return allTaskDetails;
}
}