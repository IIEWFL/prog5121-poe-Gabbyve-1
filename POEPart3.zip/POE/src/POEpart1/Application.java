












/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package POEpart1;

/**
 *
 * @author Asus
 */
import java.util.ArrayList;
import javax.swing.JOptionPane;
public class Application {
public static String NumberTask;
public static int statusChoice;
public static String taskName;
public static String taskDescription;        
public static String developerFirstName;
public static String developerLastName;
public static String developerDetails;
public static String taskDuration;
public static int taskNumber=0;
public static String taskStatus;
public static String taskID;
public static ArrayList<Integer> taskDurations=new ArrayList<>();
    public static void main(String[] args) {
        boolean continueLoop = true;
        boolean taskLoop = true;
        while (continueLoop){
        int mainChoice=showMainMenu();
          switch (mainChoice){
            case 1:   
                Registration.RegProcess();
                break;
            case 2:
                loginUser();
                JOptionPane.showMessageDialog(null,"Welcome to EasyKanban.");
                while (taskLoop){
                    int taskChoice=taskMainMenu();
                    switch (taskChoice){
                          case 1:   
                        NumberTask=JOptionPane.showInputDialog("Enter the number of tasks you would like to add.");
                        int intNumberTask=0;
                        JOptionPane.showConfirmDialog(null,"Confirm the number of tasks:"+NumberTask);
                        try{
                            intNumberTask=Integer.parseInt(NumberTask);
                        }catch(NumberFormatException e){
                            JOptionPane.showMessageDialog(null,"Invalid input.Please enter a valid number.");
                            break;
                        }
                        for(int i=0;i<intNumberTask;i++){
                            addTask();
                        }
                        break;
            case 2:
                showReport();
                break;
            case 3:
                JOptionPane.showMessageDialog(null,"Exiting...");
                taskLoop=false;
                break; 
            default:
                JOptionPane.showMessageDialog(null,"Invalid choice");
                break; 
                    
                }
}        
                break;
            case 3:
                JOptionPane.showMessageDialog(null,"exiting...");
                continueLoop=false;
                break; 
            default:
                JOptionPane.showMessageDialog(null,"Invalid choice");
                break;
        }
        }           
    }
   
    public static int showMainMenu(){
        int choice=-1;
        try{
            choice=Integer.parseInt(JOptionPane.showInputDialog(
                "Welcome to the Registration and Login system\n"+
                "1. Register\n"+
                "2. Login\n"+
                "3. Exit\n"+
                "Enter your choice:"
        ));
    } catch(NumberFormatException e){
        JOptionPane.showMessageDialog(null,"Invalid input.Please enter a number");
    }
    return choice;
  }        
    public static void registerUser(){
        Registration.userGen();
        Registration.PasswordGen();
       if(POEpart1.Login.checkUserName(Registration.username)&&POEpart1.Login.checkPasswordComplexity(Registration.password)){ 
           JOptionPane.showMessageDialog(null,"Registration successful!");
       }else{
           JOptionPane.showMessageDialog(null,"Registration failed!");
       }
    }
    public static void loginUser(){
        String loginStatus=Login.returnLoginStatus();
        if ("Login successful".equals(loginStatus)){
           JOptionPane.showMessageDialog(null,"Login successful!");
    }else{
            JOptionPane.showMessageDialog(null,"Login failed"
            );
        }
    }
    
    public static int taskMainMenu(){
        int choice=-1;
        try{
            choice=Integer.parseInt(JOptionPane.showInputDialog(
            "Please select your desired action\n"+
                    "1. Add tasks\n"+
                    "2. Show report\n"+
                    "3. Quit\n"+
                    "Enter your choice:"
    ));    
        } catch(NumberFormatException e){
        JOptionPane.showMessageDialog(null,"Invalid input.Please enter a number");
    }
    return choice;
  }        
    public static int statusMainMenu(){
        int choice=-1;
        try{
            choice=Integer.parseInt(JOptionPane.showInputDialog(
                    "Please select an option\n"+
                            "1.To do\n"+
                            "2.Doing\n"+
                            "3.Done\n"+
                            "Enter your choice:"
            ));
    }catch(NumberFormatException e){
        JOptionPane.showMessageDialog(null,"Invalid choice.Please enter a number");
    }
    return choice;
    }
   public static String taskNumber(){
       taskNumber++;
       return String.format("%02d",taskNumber);
   }
   public static String DeveloperDetails(){
       return developerFirstName +" "+developerLastName;
   }
   public static String TaskStatus(){
       switch(taskStatus){
           case "1":
               JOptionPane.showMessageDialog(null,"To Do");
           return "To Do";
       case "2":
               JOptionPane.showMessageDialog(null,"Doing");
           return "Doing";
       case "3":
               JOptionPane.showMessageDialog(null,"Done");
           return "Done";
       default:
            JOptionPane.showMessageDialog(null,"Invalid Status");  
       return null;
}
}
   public static void addTask(){
       taskName=JOptionPane.showInputDialog("Enter the name of the new task");
                        JOptionPane.showConfirmDialog(null,"Confirm the name of the task:\n"+taskName);
       taskDescription=JOptionPane.showInputDialog("Enter a task description(May not exceed 50 characters.)");
                        JOptionPane.showConfirmDialog(null,"Confirm the task description:\n"+taskDescription);
        developerFirstName=JOptionPane.showInputDialog("Enter the your first name");
        developerLastName=JOptionPane.showInputDialog("Enter the your last name");
                        JOptionPane.showConfirmDialog(null,"Confirm the detail of the developer(You)\n:"+Application.DeveloperDetails());
        taskDuration=JOptionPane.showInputDialog("Enter the estimated duration of the task (In hours)");
            int duration=0;
                try{
                    duration=Integer.parseInt(taskDuration);
                }catch(NumberFormatException e){
                    JOptionPane.showMessageDialog(null,"Invalid input.Please enter a valid number.");
                            return;
                        }
                        taskDurations.add(duration);
                
            boolean statusLoop=true;
                        while (statusLoop){
                            statusChoice=statusMainMenu();
                            switch(statusChoice){
                                case 1:
                                    taskStatus="1";
                                    statusLoop=false;
                                    break;
                                case 2:
                                   taskStatus="2";
                                   statusLoop=false;
                                    break;
                                case 3:
                                    taskStatus="3";
                                    statusLoop=false;
                                     break;
                                default:
                                    JOptionPane.showMessageDialog(null,"Invalid choice");
                                    break;
                            }
}
                         array.addDevNames(DeveloperDetails());
                         array.addTSKNames(taskName);
                         array.addTSKID(taskID);
                         array.addTSKDuration(taskDuration);
                        array.addTSKStatus(TaskStatus());
                         
                        String TaskDetails=Task.printTaskDetails();   
                        JOptionPane.showMessageDialog (null,TaskDetails);
                            Task.returnTotalHours();        
}
   public static void showReport(){
       int reportChoice=-1;
       try{
           reportChoice=Integer.parseInt(JOptionPane.showInputDialog(
                   "Please select an option\n"+
                           "1. Show all Developer names\n"
                   +"2. Show all Task names\n"
           +"3. Show all Task IDs\n"
           +"4. Show all Task Durations\n"
           +"5. Show all Task Statuses\n"
           +"6. Show all finished tasks\n"
           +"7. Show task with the longest duration\n"
           +"Please enter your choice:"
           ));
       }catch(NumberFormatException e){
           JOptionPane.showMessageDialog(null,"Invalid input.Please enter a number");  
       }
       switch (reportChoice){
           case 1:
               String[]devNames=array.FindDeveloperNames();
               JOptionPane.showMessageDialog(null,String.join("\n", devNames));
               break;
           case 2:
               String[]TSKNames=array.FindDeveloperNames();
               JOptionPane.showMessageDialog(null,String.join("\n",TSKNames));
               break;
                case 3:
               String[]TSKIDs=array.FindTSKIDs();
               JOptionPane.showMessageDialog(null,String.join("\n",TSKIDs));
               break;
                case 4:
               Double[]=array.FindTaskDurations();
               StringBuilder durations=new StringBuilder();
               for(Double duration :TSKDuration){
                   durations.append(TSKDuration).append("\n");
               }
               JOptionPane.showMessageDialog(null,String.join("\n", devNames));
               break;
                case 5:
               String[]TSKStatus=array.FindTaskStatus();
               JOptionPane.showMessageDialog(null,String.join("\n",TSKStatus));
               break;
                case 6:
                    String finishedTasks=array.showFinishedTasks();
               JOptionPane.showMessageDialog(null,String.join("\n",finishedTasks));
               break;
                case 7:
               String longestTask=array.FindLongestDuration();
               JOptionPane.showMessageDialog(null,String.join("\n",longestTask));
               break;
                default:
                    JOptionPane.showMessageDialog(null,"Invalid choice");
                    break;
       }
   }
}

                   

   

