/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package POEpart1;

/**
 *
 * @author Asus
 */
import javax.swing.JOptionPane;
public class Registration {
    public static String username;
    public static String password;
    public static String firstName;
    public static String lastName;
    
    public static void userGen(){   
        firstName = JOptionPane.showInputDialog("Enter your first name:");
        lastName=JOptionPane.showInputDialog("Enter your last name:");
        username=JOptionPane.showInputDialog("Enter your desired username:(Must contain an underscore and no greater than 5 characters)");
    }
 
    public static void PasswordGen(){
        password=JOptionPane.showInputDialog("Enter your desired password:"+"Must contain atleast 8 characters,a capital letter,a number and a special character");
      }
    public static void RegProcess(){
        userGen();
        Registration.PasswordGen();
        while(!Login.checkUserName(username)||!Login.checkPasswordComplexity(password)){
            JOptionPane.showMessageDialog(null,"Username or password does not meet requirements,Please try again.");
            userGen();
            PasswordGen();
        }   
        Login.registerUser(username, password);
         JOptionPane.showMessageDialog(null,"Registration successful");
        }
}

    




