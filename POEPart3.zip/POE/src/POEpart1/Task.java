/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package POEpart1;

import javax.swing.JOptionPane;
import java.util.ArrayList;

/**
 *
 * @author Asus
 */
public class Task {
    public static String firstTwoLetters;
    public static String TaskNumberID;
    public static String lastThreeLetters;
    public static String taskID;
    public static ArrayList<Integer> taskDurations=new ArrayList<>();
    public static boolean checkTaskDescription(){
            boolean TaskDescription=Boolean.parseBoolean(Application.taskDescription);
        if (Application.taskDescription.length()<50){
            JOptionPane.showMessageDialog(null,"Task successfully captured.");
            return true;
        }else{
            JOptionPane.showMessageDialog(null,"Please enter a task description with less than 50 characters.");
            return false;
        }
    }
    public static String createTaskID(){
        firstTwoLetters=Application.taskName.length()>=2?Application.taskName.substring(0,2).toUpperCase():Application.taskName.toUpperCase();
        TaskNumberID=String.valueOf(Application.taskNumber);
        lastThreeLetters=Application.DeveloperDetails().length()>=3?Application.DeveloperDetails().substring(Application.DeveloperDetails().length()-3).toUpperCase():Application.DeveloperDetails().toUpperCase();
         taskID=firstTwoLetters+":"+TaskNumberID+":"+lastThreeLetters;
        return taskID;
}
    public static String printTaskDetails(){
        String taskDetails="Task Details:\n"
            +"Task Status:"+Application.TaskStatus()+"\n"
            +"Developer :"+Application.DeveloperDetails()+"\n"
            +"Task Number :"+Application.taskNumber()+"\n"
            +"Task Name :"+Application.taskName+"\n"
            +"Task Description :"+Application.taskDescription+"\n"
            +"Task ID :"+Task.createTaskID()+"\n"
            +"Task Duration :"+Application.taskDuration+"hours";
    return taskDetails;
    }
    public static int returnTotalHours(){
        int TotalHours=0;
        for(int duration:Application.taskDurations){
            TotalHours+=duration;
        }
        JOptionPane.showMessageDialog(null,"Total number across all tasks is:"+TotalHours);
        return TotalHours;
    }
}
