/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package POEpart1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class arrayTest {
    
    public arrayTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addDevNames method, of class array.
     */
    @Test
    public void testAddDevNames() {
        System.out.println("addDevNames");
        String developerDetails = "";
        array.addDevNames(developerDetails);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addTSKNames method, of class array.
     */
    @Test
    public void testAddTSKNames() {
        System.out.println("addTSKNames");
        String taskName = "";
        array.addTSKNames(taskName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addTSKID method, of class array.
     */
    @Test
    public void testAddTSKID() {
        System.out.println("addTSKID");
        String taskID = "";
        array.addTSKID(taskID);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addTSKDuration method, of class array.
     */
    @Test
    public void testAddTSKDuration() {
        System.out.println("addTSKDuration");
        double taskDurations = 0.0;
        array.addTSKDuration(taskDurations);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addTSKStatus method, of class array.
     */
    @Test
    public void testAddTSKStatus() {
        System.out.println("addTSKStatus");
        String taskStatus = "";
        array.addTSKStatus(taskStatus);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of FindDeveloperNames method, of class array.
     */
    @Test
    public void testFindDeveloperNames() {
        System.out.println("FindDeveloperNames");
        String[] expResult = null;
        String[] result = array.FindDeveloperNames();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of FindTaskNames method, of class array.
     */
    @Test
    public void testFindTaskNames() {
        System.out.println("FindTaskNames");
        String[] expResult = null;
        String[] result = array.FindTaskNames();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of FindTSKIDs method, of class array.
     */
    @Test
    public void testFindTSKIDs() {
        System.out.println("FindTSKIDs");
        String[] expResult = null;
        String[] result = array.FindTSKIDs();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of FindTaskDurations method, of class array.
     */
    @Test
    public void testFindTaskDurations() {
        System.out.println("FindTaskDurations");
        Double[] expResult = null;
        Double[] result = array.FindTaskDurations();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of FindTaskStatus method, of class array.
     */
    @Test
    public void testFindTaskStatus() {
        System.out.println("FindTaskStatus");
        String[] expResult = null;
        String[] result = array.FindTaskStatus();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showFinishedTasks method, of class array.
     */
    @Test
    public void testShowFinishedTasks() {
        System.out.println("showFinishedTasks");
        String expResult = "";
        String result = array.showFinishedTasks();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of FindLongestDuration method, of class array.
     */
    @Test
    public void testFindLongestDuration() {
        System.out.println("FindLongestDuration");
        String expResult = "";
        String result = array.FindLongestDuration();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of TaskNameSearch method, of class array.
     */
    @Test
    public void testTaskNameSearch() {
        System.out.println("TaskNameSearch");
        String expResult = "";
        String result = array.TaskNameSearch();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of DeveloperNameSearch method, of class array.
     */
    @Test
    public void testDeveloperNameSearch() {
        System.out.println("DeveloperNameSearch");
        String expResult = "";
        String result = array.DeveloperNameSearch();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of NameDelete method, of class array.
     */
    @Test
    public void testNameDelete() {
        System.out.println("NameDelete");
        String expResult = "";
        String result = array.NameDelete();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of FindAllTaskDetails method, of class array.
     */
    @Test
    public void testFindAllTaskDetails() {
        System.out.println("FindAllTaskDetails");
        String expResult = "";
        String result = array.FindAllTaskDetails();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
