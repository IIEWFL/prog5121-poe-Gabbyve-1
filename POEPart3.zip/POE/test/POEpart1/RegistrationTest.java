/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package POEpart1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Asus
 */
public class RegistrationTest {
    
    public RegistrationTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of userGen method, of class Registration.
     */
    @Test
    public void testUserGen() {
        System.out.println("testuserGen");
        String generatedUser = Registration.userGen();
        assertNotNull(generatedUser);
        assertEquals(5,generatedUser.length());
    }
    /**
     * Test of PasswordGen method, of class Registration.
     */
    @Test
    public void testPasswordGen() {
        System.out.println("testPasswordGen");
        String generatedPassword = Registration.PasswordGen();
        assertNotNull(generatedPassword);
        assertEquals(8,generatedPassword.length());
        assertTrue(generatedPassword.matches(".*[A-Z].*"));
        assertTrue(generatedPassword.matches(".*\\d.*"));
        assertTrue(generatedPassword.matches(".*[!@#$%^&()-+=?<>].*"));
    }

    /**
     * Test of Fname method, of class Registration.
     */
    @Test
    public void testFname() {
        System.out.println("Fname");
        Registration instance = new Registration();
        String expResult = "";
        String result = instance.Fname();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Lname method, of class Registration.
     */
    @Test
    public void testLname() {
        System.out.println("Lname");
        Registration instance = new Registration();
        String expResult = "";
        String result = instance.Lname();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
