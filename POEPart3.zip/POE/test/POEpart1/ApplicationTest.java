/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package POEpart1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Asus
 */
public class ApplicationTest {
    
    public ApplicationTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class Application.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Application.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class Application.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        Application.registerUser();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class Application.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        Application.loginUser();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showMainMenu method, of class Application.
     */
    @org.junit.Test
    public void testShowMainMenu() {
        System.out.println("showMainMenu");
        int expResult = 0;
        int result = Application.showMainMenu();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskMainMenu method, of class Application.
     */
    @org.junit.Test
    public void testTaskMainMenu() {
        System.out.println("taskMainMenu");
        int expResult = 0;
        int result = Application.taskMainMenu();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of statusMainMenu method, of class Application.
     */
    @org.junit.Test
    public void testStatusMainMenu() {
        System.out.println("statusMainMenu");
        int expResult = 0;
        int result = Application.statusMainMenu();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskNumber method, of class Application.
     */
    @org.junit.Test
    public void testTaskNumber() {
        System.out.println("taskNumber");
        String expResult = "";
        String result = Application.taskNumber();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of DeveloperDetails method, of class Application.
     */
    @org.junit.Test
    public void testDeveloperDetails() {
        System.out.println("DeveloperDetails");
        String expResult = "";
        String result = Application.DeveloperDetails();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of TaskStatus method, of class Application.
     */
    @org.junit.Test
    public void testTaskStatus() {
        System.out.println("TaskStatus");
        String expResult = "";
        String result = Application.TaskStatus();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
